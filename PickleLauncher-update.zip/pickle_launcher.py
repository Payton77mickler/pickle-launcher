import json, os, sys, threading, urllib.request, subprocess, shutil
from pathlib import Path
import tkinter as tk
from tkinter import ttk, filedialog, messagebox

def max(a,b): return a if a>b else b

APP = "Pickle Launcher"
APP_VERSION = "1.0.1"
UPDATE_URL = "https://raw.githubusercontent.com/picklelauncher/pickle-launcher/main/version.json"  # host your own
_cfg = Path(__file__).parent / "update_url.txt"
if _cfg.exists():
    UPDATE_URL = _cfg.read_text().strip()
DOWNLOAD_URL = "https://github.com/picklelauncher/pickle-launcher/releases/latest"
DATA = Path(os.environ.get("APPDATA", ".")) / "PickleLauncher"
DATA.mkdir(parents=True, exist_ok=True)
MC = DATA / "minecraft"
for d in ["versions","libraries","assets","mods","profiles","cache","natives"]:
    (MC/d).mkdir(parents=True, exist_ok=True)
SETTINGS = DATA / "settings.json"
MODULES_FILE = Path(__file__).parent / "assets" / "modules.json"

def load_settings():
    if SETTINGS.exists():
        try: return json.loads(SETTINGS.read_text())
        except: pass
    return {"minecraft_dir":str(MC),"java_path":"","memory_mb":2048,"low_end_mode":False,"close_on_launch":True,"show_console":False}

def save_settings(s):
    SETTINGS.write_text(json.dumps(s,indent=2))

S = load_settings()
if "minecraft_dir" not in S: S["minecraft_dir"]=str(MC)
MC = Path(S["minecraft_dir"])
for d in ["versions","libraries","assets","mods","profiles","cache","natives"]:
    (MC/d).mkdir(parents=True, exist_ok=True)

def load_modules():
    if MODULES_FILE.exists():
        try: return json.loads(MODULES_FILE.read_text())
        except: pass
    return []

MODULES = load_modules()

BG="#0d1a0d"; PANEL="#142814"; PANEL2="#1c381c"; ACCENT="#7cb342"; ACCENT2="#558b2f"
TEXT="#e8f5e9"; MUTED="#a5d6a7"; GREEN="#cddc39"

class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title(APP)
        self.geometry("1200x760")
        self.minsize(960,600)
        self.configure(bg=BG)
        self.style = ttk.Style(self)
        self.style.theme_use("clam")
        self._style()
        self.profiles = self.load_profiles()
        self.selected_profile = 0
        self.mods = []
        self.enabled_modules = set()
        if self.profiles:
            self.enabled_modules = set(self.profiles[0].get("enabled_modules",[]))
        self.versions_list = []
        self.selected_version = ""
        self.selected_loader = "Vanilla"
        self.loader_versions = []
        self.selected_loader_version = ""
        self.busy = False
        self.home_combo_var = tk.StringVar()
        self.gv_var = tk.StringVar()
        self.loader_var = tk.StringVar(value="Vanilla")
        self.lv_var = tk.StringVar()
        self._build()
        self.refresh_mods()
        threading.Thread(target=self.fetch_manifest, daemon=True).start()
        threading.Thread(target=self.check_for_updates, daemon=True).start()

    def _style(self):
        self.style.configure(".", background=PANEL, foreground=TEXT, font=("Segoe UI",10))
        self.style.configure("TFrame", background=PANEL)
        self.style.configure("TLabel", background=PANEL, foreground=TEXT)
        self.style.configure("TButton", background=PANEL2, foreground=TEXT, borderwidth=0, focusthickness=0, padding=6)
        self.style.map("TButton", background=[("active", ACCENT)], foreground=[("active","#000")])
        self.style.configure("Accent.TButton", background=ACCENT, foreground="#000", font=("Segoe UI",12,"bold"))
        self.style.map("Accent.TButton", background=[("active", ACCENT2)])
        self.style.configure("TEntry", fieldbackground=PANEL2, foreground=TEXT, borderwidth=0)
        self.style.configure("TCombobox", fieldbackground=PANEL2, foreground=TEXT, borderwidth=0, padding=4)

    def _build(self):
        side = tk.Frame(self, bg="#0a1a0a", width=170)
        side.pack(side="left", fill="y")
        side.pack_propagate(False)
        tk.Label(side, text="⚡", fg=ACCENT, bg="#0a1a0a", font=("Segoe UI",24)).pack(anchor="w", padx=14, pady=(14,0))
        tk.Label(side, text="Pickle", fg=ACCENT, bg="#0a1a0a", font=("Segoe UI",18,"bold")).pack(anchor="w", padx=14)
        tk.Label(side, text="Launcher", fg=MUTED, bg="#0a1a0a", font=("Segoe UI",9)).pack(anchor="w", padx=14, pady=(0,16))
        self.nav_buttons = {}
        for key, icon, label in [("home","🏠","Home"),("instances","📦","Instances"),("mods","🧩","Mods"),("modules","⚙","Modules"),("profiles","👤","Profiles"),("settings","🔧","Settings")]:
            b = tk.Button(side, text=f"  {icon}  {label}", anchor="w", bg="#0a1a0a", fg=MUTED, bd=0, padx=10, pady=10, font=("Segoe UI",11), activebackground=ACCENT, activeforeground="#000", command=lambda k=key: self.show_tab(k))
            b.pack(fill="x", padx=8, pady=2)
            self.nav_buttons[key]=b
        self.status_lbl = tk.Label(side, text="Ready", fg=MUTED, bg="#0a1a0a", font=("Segoe UI",9), justify="left", wraplength=150)
        self.status_lbl.pack(side="bottom", anchor="w", padx=12, pady=10)

        main = tk.Frame(self, bg=BG)
        main.pack(side="left", fill="both", expand=True)
        top = tk.Frame(main, bg=PANEL, height=38)
        top.pack(fill="x")
        top.pack_propagate(False)
        tk.Label(top, text="Rust-powered  •  low-end friendly", fg=MUTED, bg=PANEL, font=("Segoe UI",9)).pack(side="left", padx=16, pady=10)
        self.java_top = tk.Label(top, text="Java: detecting...", fg=GREEN, bg=PANEL, font=("Segoe UI",9))
        self.java_top.pack(side="right", padx=16, pady=10)

        self.content = tk.Frame(main, bg=BG)
        self.content.pack(fill="both", expand=True, padx=20, pady=20)

        self.tabs = {}
        for key in ["home","instances","mods","modules","profiles","settings"]:
            f = tk.Frame(self.content, bg=BG)
            self.tabs[key]=f
        self.show_tab("home")
        self.build_home()
        self.build_instances()
        self.build_mods()
        self.build_modules()
        self.build_profiles()
        self.build_settings()

    def show_tab(self, key):
        for k,f in self.tabs.items():
            f.pack_forget()
        self.tabs[key].pack(fill="both", expand=True)
        for k,b in self.nav_buttons.items():
            b.configure(bg=ACCENT if k==key else "#0a1a0a", fg="#000" if k==key else MUTED)

    def set_status(self, msg):
        self.status_lbl.configure(text=msg)

    # ---------- HOME ----------
    def build_home(self):
        f = self.tabs["home"]
        tk.Label(f, text="Home", fg=ACCENT, bg=BG, font=("Segoe UI",24,"bold")).pack(anchor="w")
        card = tk.Frame(f, bg=PANEL2, padx=24, pady=24)
        card.pack(fill="x", pady=(14,0))
        self.home_name = tk.Label(card, text="Default", fg=TEXT, bg=PANEL2, font=("Segoe UI",24,"bold"))
        self.home_name.pack(anchor="w")
        self.home_sub = tk.Label(card, text="1.20.4  •  Fabric", fg=MUTED, bg=PANEL2, font=("Segoe UI",12))
        self.home_sub.pack(anchor="w", pady=(2,0))
        self.home_mem = tk.Label(card, text="Memory: 1024 MB", fg=MUTED, bg=PANEL2, font=("Segoe UI",10))
        self.home_mem.pack(anchor="w", pady=(6,14))
        row = tk.Frame(card, bg=PANEL2)
        row.pack(anchor="w", fill="x")
        tk.Label(row, text="Instance", fg=MUTED, bg=PANEL2, font=("Segoe UI",10)).pack(side="left")
        self.home_combo = ttk.Combobox(row, textvariable=self.home_combo_var, values=[p.get("name","") for p in self.profiles], width=30, font=("Segoe UI",11))
        self.home_combo.pack(side="left", padx=10)
        self.home_combo.bind("<<ComboboxSelected>>", lambda e: self.switch_instance(self.home_combo.current()))
        tk.Button(row, text="New instance", bg=PANEL, fg=TEXT, bd=0, padx=12, pady=6, font=("Segoe UI",10), command=lambda: self.show_tab("profiles")).pack(side="left", padx=6)
        play = tk.Button(f, text="▶   PLAY", bg=ACCENT, fg="#000", bd=0, font=("Segoe UI",28,"bold"), pady=18, cursor="hand2", command=self.launch)
        play.pack(fill="x", pady=24)
        self.lowend_lbl = tk.Label(f, text="✓ Low-end mode active — memory capped, heavy effects off.", fg=GREEN, bg=BG, font=("Segoe UI",10))
        self.lowend_lbl.pack(anchor="w")
        stats = tk.Frame(f, bg=BG)
        stats.pack(anchor="w", pady=14)
        self.stat_java = tk.Label(stats, text="☕ Java: 0", fg=MUTED, bg=BG, font=("Segoe UI",10))
        self.stat_java.pack(side="left", padx=(0,20))
        self.stat_mods = tk.Label(stats, text="🧩 Mods: 0", fg=MUTED, bg=BG, font=("Segoe UI",10))
        self.stat_mods.pack(side="left", padx=(0,20))
        self.stat_modules = tk.Label(stats, text=f"⚙ Modules: {len(MODULES)}", fg=MUTED, bg=BG, font=("Segoe UI",10))
        self.stat_modules.pack(side="left", padx=(0,20))
        tk.Button(stats, text="Open folder", bg=PANEL, fg=MUTED, bd=0, padx=12, pady=4, command=self.open_mc_folder).pack(side="left")
        self.refresh_home()

    def switch_instance(self, idx):
        if idx < 0 or idx >= len(self.profiles): return
        self.selected_profile = idx
        self.enabled_modules = set(self.profiles[idx].get("enabled_modules",[]))
        self.refresh_home()
        self.render_modules()

    def refresh_home(self):
        p = self.profiles[self.selected_profile] if self.profiles else {}
        self.home_name.configure(text=p.get("name","Default"))
        gv = p.get("game_version") or self.selected_version or "1.20.4"
        self.home_sub.configure(text=f"{gv}  •  {p.get('loader','Vanilla')}")
        mem = p.get("memory_mb") or S.get("memory_mb",2048)
        self.home_mem.configure(text=f"Memory: {mem} MB" + ("  (low-end capped)" if S.get("low_end_mode") else ""))
        self.stat_java.configure(text=f"☕ Java: {len(self.detect_java())}")
        self.stat_mods.configure(text=f"🧩 Mods: {len(self.mods)}")
        self.lowend_lbl.configure(text="✓ Low-end mode active — memory capped, heavy effects off." if S.get("low_end_mode") else "")
        if self.profiles:
            self.home_combo.set(p.get("name",""))

    # ---------- INSTANCES ----------
    def build_instances(self):
        f = self.tabs["instances"]
        tk.Label(f, text="Instances", fg=ACCENT, bg=BG, font=("Segoe UI",24,"bold")).pack(anchor="w")
        card = tk.Frame(f, bg=PANEL2, padx=24, pady=20)
        card.pack(fill="x", pady=(14,0))
        tk.Label(card, text="Install Version", fg=ACCENT, bg=PANEL2, font=("Segoe UI",13,"bold")).pack(anchor="w", pady=(0,10))
        # Game version dropdown
        r = tk.Frame(card, bg=PANEL2); r.pack(fill="x", pady=6)
        tk.Label(r, text="Game version", fg=MUTED, bg=PANEL2, width=16, anchor="w", font=("Segoe UI",11)).pack(side="left")
        self.gv_combo = ttk.Combobox(r, textvariable=self.gv_var, width=34, font=("Segoe UI",11))
        self.gv_combo.pack(side="left", padx=8)
        # Loader dropdown
        r = tk.Frame(card, bg=PANEL2); r.pack(fill="x", pady=6)
        tk.Label(r, text="Loader", fg=MUTED, bg=PANEL2, width=16, anchor="w", font=("Segoe UI",11)).pack(side="left")
        self.loader_combo = ttk.Combobox(r, textvariable=self.loader_var, values=["Vanilla","Fabric","Forge","Quilt","NeoForge"], width=34, font=("Segoe UI",11))
        self.loader_combo.pack(side="left", padx=8)
        # Loader version dropdown
        r = tk.Frame(card, bg=PANEL2); r.pack(fill="x", pady=6)
        tk.Label(r, text="Loader version", fg=MUTED, bg=PANEL2, width=16, anchor="w", font=("Segoe UI",11)).pack(side="left")
        self.lv_combo = ttk.Combobox(r, textvariable=self.lv_var, width=34, font=("Segoe UI",11))
        self.lv_combo.pack(side="left", padx=8)
        r = tk.Frame(card, bg=PANEL2); r.pack(fill="x", pady=12)
        tk.Button(r, text="Install", bg=ACCENT, fg="#000", bd=0, padx=18, pady=8, font=("Segoe UI",11,"bold"), command=self.install_version).pack(side="left")
        tk.Button(r, text="Perf Pack (Plain)", bg=PANEL, fg=MUTED, bd=0, padx=18, pady=8, font=("Segoe UI",11), command=self.install_perf).pack(side="left", padx=8)
        tk.Label(f, text="Installed versions (minecraft/versions):", fg=MUTED, bg=BG, font=("Segoe UI",10)).pack(anchor="w", pady=(12,4))
        self.installed_box = tk.Text(f, bg=PANEL2, fg=TEXT, height=14, bd=0, font=("Consolas",9))
        self.installed_box.pack(fill="both", expand=True)
        self.loader_var.trace_add("write", lambda *_: self.update_loader_versions())
        self.gv_var.trace_add("write", lambda *_: self.update_loader_versions())

    def fetch_manifest(self):
        try:
            data = urllib.request.urlopen("https://launchermeta.mojang.com/mc/game/version_manifest_v2.json", timeout=20).read()
            m = json.loads(data)
            self.versions_list = [v["id"] for v in m["versions"] if v["type"]=="release"][:50]
            self.selected_version = m["latest"]["release"]
            self.after(0, lambda: self.gv_combo.configure(values=self.versions_list))
            self.after(0, lambda: self.gv_var.set(self.selected_version))
            self.set_status(f"Loaded {len(m['versions'])} versions")
        except Exception as e:
            self.after(0, lambda: self.set_status(f"Manifest error: {e}"))

    def update_loader_versions(self):
        gv = self.gv_var.get()
        loader = self.loader_var.get()
        if loader == "Vanilla" or not gv:
            self.lv_var.set("")
            self.lv_combo.configure(values=[])
            return
        def worker():
            try:
                if loader == "Fabric":
                    url = f"https://meta.fabricmc.net/v2/versions/loader/{gv}"
                    arr = json.loads(urllib.request.urlopen(url).read())
                    vers = [e["loader"]["version"] for e in arr]
                elif loader == "Quilt":
                    url = f"https://meta.quiltmc.org/v3/versions/loader/{gv}"
                    arr = json.loads(urllib.request.urlopen(url).read())
                    vers = [e["loader"]["version"] for e in arr]
                else:
                    vers = []
                self.after(0, lambda: self.lv_combo.configure(values=vers))
                if vers: self.after(0, lambda: self.lv_var.set(vers[0]))
            except Exception as e:
                self.after(0, lambda: self.set_status(f"Loader err: {e}"))
        threading.Thread(target=worker, daemon=True).start()

    def install_version(self):
        gv = self.gv_var.get(); loader = self.loader_var.get(); lv = self.lv_var.get()
        if not gv:
            messagebox.showwarning(APP,"Select a version"); return
        self.set_status("Installing...")
        def worker():
            try:
                vdir = MC/"versions"/gv
                vdir.mkdir(parents=True, exist_ok=True)
                if not (vdir/f"{gv}.json").exists():
                    man = json.loads(urllib.request.urlopen("https://launchermeta.mojang.com/mc/game/version_manifest_v2.json").read())
                    entry = next(v for v in man["versions"] if v["id"]==gv)
                    detail = json.loads(urllib.request.urlopen(entry["url"]).read())
                    (vdir/f"{gv}.json").write_text(json.dumps(detail,indent=2))
                    client = detail["downloads"]["client"]
                    jar = vdir/f"{gv}.jar"
                    if not jar.exists():
                        urllib.request.urlretrieve(client["url"], jar)
                if loader in ("Fabric","Quilt"):
                    if loader=="Fabric":
                        url = f"https://meta.fabricmc.net/v2/versions/loader/{gv}/{lv}/profile/json"
                    else:
                        url = f"https://meta.quiltmc.org/v3/versions/loader/{gv}/{lv}/profile/json"
                    prof = json.loads(urllib.request.urlopen(url).read())
                    vid = prof["id"]
                    vd = MC/"versions"/vid
                    vd.mkdir(parents=True, exist_ok=True)
                    (vd/f"{vid}.json").write_text(json.dumps(prof,indent=2))
                    self.set_status(f"Installed {vid}")
                elif loader in ("Forge","NeoForge"):
                    self.set_status("Forge/NeoForge: download installer manually.")
                else:
                    self.set_status(f"Installed {gv}")
                self.after(0, self.refresh_installed)
            except Exception as e:
                self.after(0, lambda: self.set_status(f"Install failed: {e}"))
        threading.Thread(target=worker, daemon=True).start()

    def install_perf(self):
        gv = self.gv_var.get(); loader = self.loader_var.get()
        self.set_status("Installing performance pack...")
        def worker():
            mods = MC/"mods"; mods.mkdir(parents=True, exist_ok=True)
            perf = ["sodium","lithium","starlight","ferritecore","entityculling","krypton","lazydfu","dynamic-fps","smoothboot","clumps"]
            count=0
            for name in perf:
                try:
                    url = f"https://api.modrinth.com/v2/search?query={name}&facets=[[\"versions:{gv}\"],[\"project_type:mod\"]]&limit=3"
                    hits = json.loads(urllib.request.urlopen(url).read())["hits"]
                    pid = None
                    for h in hits:
                        if h.get("slug","").lower()==name or h.get("title","").lower().replace(" ","-")==name:
                            pid = h["project_id"]; break
                    if not pid and hits: pid = hits[0]["project_id"]
                    if not pid: continue
                    ver_url = f"https://api.modrinth.com/v2/project/{pid}/version?game_versions=[\"{gv}\"]&loaders=[\"{loader.lower()}\"]"
                    versions = json.loads(urllib.request.urlopen(ver_url).read())
                    if not versions: continue
                    files = versions[0]["files"]
                    f = next((x for x in files if x.get("primary")), files[0])
                    dest = mods / f["filename"]
                    if not dest.exists():
                        urllib.request.urlretrieve(f["url"], dest)
                    count+=1
                except Exception:
                    pass
            self.after(0, lambda: self.set_status(f"Perf pack: {count} mods"))
            self.after(0, self.refresh_mods)
        threading.Thread(target=worker, daemon=True).start()

    def refresh_installed(self):
        box = self.installed_box
        box.delete("1.0","end")
        vdir = MC/"versions"
        if vdir.exists():
            for d in sorted(vdir.iterdir()):
                if d.is_dir():
                    box.insert("end", d.name + "\n")

    # ---------- MODS ----------
    def build_mods(self):
        f = self.tabs["mods"]
        tk.Label(f, text="Mods", fg=ACCENT, bg=BG, font=("Segoe UI",24,"bold")).pack(anchor="w")
        row = tk.Frame(f, bg=BG); row.pack(fill="x", pady=10)
        tk.Button(row, text="Add mod (.jar)", bg=ACCENT, fg="#000", bd=0, padx=14, pady=7, font=("Segoe UI",10,"bold"), command=self.add_mod).pack(side="left")
        tk.Button(row, text="Refresh", bg=PANEL, fg=MUTED, bd=0, padx=14, pady=7, command=self.refresh_mods).pack(side="left", padx=6)
        tk.Button(row, text="Open mods folder", bg=PANEL, fg=MUTED, bd=0, padx=14, pady=7, command=lambda: self.open_path(MC/"mods")).pack(side="left")
        self.mods_frame = tk.Frame(f, bg=BG)
        self.mods_frame.pack(fill="both", expand=True)
        self.refresh_mods()

    def refresh_mods(self):
        self.mods = []
        mdir = MC/"mods"
        if mdir.exists():
            for p in sorted(mdir.iterdir()):
                if p.is_file() and (p.name.endswith(".jar") or p.name.endswith(".zip") or p.name.endswith(".disabled")):
                    self.mods.append(p)
        for w in self.mods_frame.winfo_children(): w.destroy()
        if not self.mods:
            tk.Label(self.mods_frame, text="No mods installed. Add .jar files.", fg=MUTED, bg=BG).pack(anchor="w", pady=10)
            return
        for p in self.mods:
            row = tk.Frame(self.mods_frame, bg=PANEL2, padx=12, pady=8)
            row.pack(fill="x", pady=3)
            enabled = not p.name.endswith(".disabled")
            tk.Label(row, text=p.name, fg=TEXT, bg=PANEL2, font=("Segoe UI",10,"bold")).pack(side="left")
            tk.Label(row, text="enabled" if enabled else "disabled", fg=GREEN if enabled else MUTED, bg=PANEL2, font=("Segoe UI",9)).pack(side="left", padx=10)
            tk.Button(row, text="Delete", bg=PANEL, fg=MUTED, bd=0, padx=8, pady=3, command=lambda pp=p: self.delete_mod(pp)).pack(side="right")
            tk.Button(row, text="Toggle", bg=PANEL, fg=MUTED, bd=0, padx=8, pady=3, command=lambda pp=p: self.toggle_mod(pp)).pack(side="right", padx=4)
        self.refresh_home()

    def add_mod(self):
        path = filedialog.askopenfilename(title="Select mod", filetypes=[("Mod files","*.jar *.zip")])
        if path:
            dest = MC/"mods"/Path(path).name
            shutil.copy(path, dest)
            self.refresh_mods()
            self.set_status("Mod added")

    def toggle_mod(self, p):
        if p.name.endswith(".disabled"):
            p.rename(p.with_name(p.name[:-9]))
        else:
            p.rename(p.with_name(p.name+".disabled"))
        self.refresh_mods()

    def delete_mod(self, p):
        if messagebox.askyesno(APP, f"Delete {p.name}?"):
            p.unlink()
            self.refresh_mods()

    # ---------- MODULES ----------
    def build_modules(self):
        f = self.tabs["modules"]
        tk.Label(f, text="Modules (100 in-game)", fg=ACCENT, bg=BG, font=("Segoe UI",24,"bold")).pack(anchor="w")
        row = tk.Frame(f, bg=BG); row.pack(fill="x", pady=10)
        self.mod_filter = tk.StringVar()
        tk.Entry(row, textvariable=self.mod_filter, width=30, bg=PANEL2, fg=TEXT, bd=0, insertbackground=TEXT).pack(side="left", ipady=4)
        self.mod_filter.trace_add("write", lambda *_: self.render_modules())
        self.mod_cat = tk.StringVar(value="All")
        cats = sorted(set(m.get("category","") for m in MODULES))
        ttk.Combobox(row, textvariable=self.mod_cat, values=["All"]+cats, width=18).pack(side="left", padx=8)
        self.mod_cat.trace_add("write", lambda *_: self.render_modules())
        self.enabled_count_lbl = tk.Label(row, text="", fg=MUTED, bg=BG, font=("Segoe UI",10))
        self.enabled_count_lbl.pack(side="left", padx=10)
        tk.Button(row, text="Enable defaults", bg=ACCENT, fg="#000", bd=0, padx=12, pady=6, command=self.enable_defaults).pack(side="left", padx=4)
        tk.Button(row, text="Clear all", bg=PANEL, fg=MUTED, bd=0, padx=12, pady=6, command=self.clear_modules).pack(side="left")
        self.modules_canvas = tk.Canvas(f, bg=BG, bd=0, highlightthickness=0)
        sb = ttk.Scrollbar(f, orient="vertical", command=self.modules_canvas.yview)
        self.modules_canvas.configure(yscrollcommand=sb.set)
        sb.pack(side="right", fill="y")
        self.modules_canvas.pack(side="left", fill="both", expand=True)
        self.modules_inner = tk.Frame(self.modules_canvas, bg=BG)
        self.modules_canvas.create_window((0,0), window=self.modules_inner, anchor="nw")
        self.modules_inner.bind("<Configure>", lambda e: self.modules_canvas.configure(scrollregion=self.modules_canvas.bbox("all")))
        self.render_modules()

    def render_modules(self):
        for w in self.modules_inner.winfo_children(): w.destroy()
        filt = self.mod_filter.get().lower()
        cat = self.mod_cat.get()
        for m in MODULES:
            if filt and filt not in m["name"].lower(): continue
            if cat != "All" and m.get("category") != cat: continue
            is_on = m["id"] in self.enabled_modules
            row = tk.Frame(self.modules_inner, bg=PANEL2, padx=12, pady=7)
            row.pack(fill="x", pady=2)
            left = tk.Frame(row, bg=PANEL2)
            left.pack(side="left", fill="x", expand=True)
            tk.Label(left, text=m["name"], fg=TEXT, bg=PANEL2, font=("Segoe UI",10,"bold")).pack(anchor="w")
            tk.Label(left, text=m.get("category",""), fg=ACCENT, bg=PANEL2, font=("Segoe UI",8)).pack(anchor="w")
            tk.Label(left, text=m.get("description",""), fg=MUTED, bg=PANEL2, font=("Segoe UI",8)).pack(anchor="w")
            var = tk.BooleanVar(value=is_on)
            tk.Checkbutton(row, variable=var, bg=PANEL2, fg=TEXT, selectcolor=PANEL, activebackground=PANEL2, command=lambda mid=m["id"], v=var: self.toggle_module(mid, v.get())).pack(side="right")
        self.enabled_count_lbl.configure(text=f"Enabled: {len(self.enabled_modules)}/100")

    def toggle_module(self, mid, on):
        if on: self.enabled_modules.add(mid)
        else: self.enabled_modules.discard(mid)
        if self.profiles:
            self.profiles[self.selected_profile]["enabled_modules"] = sorted(self.enabled_modules)
        self.enabled_count_lbl.configure(text=f"Enabled: {len(self.enabled_modules)}/100")

    def enable_defaults(self):
        for m in MODULES:
            if m.get("default_on"): self.enabled_modules.add(m["id"])
        if self.profiles:
            self.profiles[self.selected_profile]["enabled_modules"] = sorted(self.enabled_modules)
        self.render_modules()

    def clear_modules(self):
        self.enabled_modules.clear()
        if self.profiles:
            self.profiles[self.selected_profile]["enabled_modules"] = []
        self.render_modules()

    # ---------- PROFILES ----------
    def load_profiles(self):
        pdir = MC/"profiles"
        out = []
        if pdir.exists():
            for p in pdir.glob("*.json"):
                try: out.append(json.loads(p.read_text()))
                except: pass
        if not out:
            out = [{"name":"Default","game_version":"1.20.4","loader":"Vanilla","loader_version":"","memory_mb":None,"jvm_args":"","game_args":"","icon":None,"enabled_modules":[],"plain_performance":True}]
        return out

    def save_profiles(self):
        pdir = MC/"profiles"; pdir.mkdir(parents=True, exist_ok=True)
        for p in self.profiles:
            (pdir/(p["name"]+".json")).write_text(json.dumps(p,indent=2))

    def build_profiles(self):
        f = self.tabs["profiles"]
        tk.Label(f, text="Profiles", fg=ACCENT, bg=BG, font=("Segoe UI",24,"bold")).pack(anchor="w")
        row = tk.Frame(f, bg=BG); row.pack(fill="x", pady=10)
        tk.Button(row, text="New Profile", bg=ACCENT, fg="#000", bd=0, padx=14, pady=7, font=("Segoe UI",10,"bold"), command=self.new_profile).pack(side="left")
        tk.Button(row, text="Save", bg=PANEL, fg=MUTED, bd=0, padx=14, pady=7, command=self.save_profile).pack(side="left", padx=6)
        tk.Button(row, text="Delete", bg=PANEL, fg=MUTED, bd=0, padx=14, pady=7, command=self.delete_profile).pack(side="left")
        panes = tk.Frame(f, bg=BG); panes.pack(fill="both", expand=True)
        left = tk.Frame(panes, bg=PANEL2, width=240); left.pack(side="left", fill="y", padx=(0,10)); left.pack_propagate(False)
        self.profile_listbox = tk.Listbox(left, bg=PANEL2, fg=TEXT, bd=0, highlightthickness=0, font=("Segoe UI",11), selectbackground=ACCENT, selectforeground="#000")
        self.profile_listbox.pack(fill="both", expand=True, padx=8, pady=8)
        self.profile_listbox.bind("<<ListboxSelect>>", self.on_profile_select)
        right = tk.Frame(panes, bg=PANEL2, padx=20, pady=20); right.pack(side="left", fill="both", expand=True)
        self.profile_editor = right
        self.render_profile_list()
        self.render_profile_editor()

    def render_profile_list(self):
        self.profile_listbox.delete(0,"end")
        for p in self.profiles:
            self.profile_listbox.insert("end", p.get("name",""))
        if self.profiles:
            self.profile_listbox.selection_set(self.selected_profile)

    def on_profile_select(self, e):
        sel = self.profile_listbox.curselection()
        if sel:
            self.selected_profile = sel[0]
            self.enabled_modules = set(self.profiles[self.selected_profile].get("enabled_modules",[]))
            self.render_profile_editor()
            self.render_modules()
            self.refresh_home()

    def render_profile_editor(self):
        for w in self.profile_editor.winfo_children(): w.destroy()
        if not self.profiles: return
        p = self.profiles[self.selected_profile]
        def field(label, key):
            r = tk.Frame(self.profile_editor, bg=PANEL2); r.pack(fill="x", pady=5)
            tk.Label(r, text=label, fg=MUTED, bg=PANEL2, width=16, anchor="w", font=("Segoe UI",10)).pack(side="left")
            var = tk.StringVar(value=str(p.get(key,"") or ""))
            e = tk.Entry(r, textvariable=var, bg=PANEL, fg=TEXT, bd=0, insertbackground=TEXT, font=("Segoe UI",10))
            e.pack(side="left", fill="x", expand=True, ipady=3)
            def on_change(*_):
                p[key] = var.get()
            var.trace_add("write", on_change)
        field("Name","name")
        field("Game version","game_version")
        field("Loader","loader")
        field("Loader ver","loader_version")
        r = tk.Frame(self.profile_editor, bg=PANEL2); r.pack(fill="x", pady=5)
        tk.Label(r, text="Memory (MB)", fg=MUTED, bg=PANEL2, width=16, anchor="w", font=("Segoe UI",10)).pack(side="left")
        var = tk.StringVar(value=str(p.get("memory_mb") or ""))
        e = tk.Entry(r, textvariable=var, bg=PANEL, fg=TEXT, bd=0, insertbackground=TEXT, font=("Segoe UI",10))
        e.pack(side="left", fill="x", expand=True, ipady=3)
        def on_mem(*_):
            v = var.get()
            p["memory_mb"] = int(v) if v.isdigit() else None
        var.trace_add("write", on_mem)
        field("JVM args","jvm_args")
        cb_var = tk.BooleanVar(value=p.get("plain_performance",True))
        tk.Checkbutton(self.profile_editor, text="Plain mode: auto-install performance mods", variable=cb_var, bg=PANEL2, fg=TEXT, selectcolor=PANEL, font=("Segoe UI",10), command=lambda: p.__setitem__("plain_performance", cb_var.get())).pack(anchor="w", pady=8)

    def new_profile(self):
        p = {"name":f"Profile {len(self.profiles)+1}","game_version":self.selected_version or "1.20.4","loader":"Vanilla","loader_version":"","memory_mb":None,"jvm_args":"","game_args":"","icon":None,"enabled_modules":[],"plain_performance":True}
        self.profiles.append(p)
        self.selected_profile = len(self.profiles)-1
        self.enabled_modules = set()
        self.save_profiles()
        self.render_profile_list()
        self.render_profile_editor()
        self.refresh_home()

    def save_profile(self):
        if not self.profiles: return
        self.profiles[self.selected_profile]["enabled_modules"] = sorted(self.enabled_modules)
        self.save_profiles()
        self.set_status("Profile saved")

    def delete_profile(self):
        if not self.profiles: return
        if messagebox.askyesno(APP, "Delete profile?"):
            del self.profiles[self.selected_profile]
            if not self.profiles: self.new_profile()
            self.selected_profile = max(0, self.selected_profile-1)
            self.enabled_modules = set(self.profiles[self.selected_profile].get("enabled_modules",[]))
            self.save_profiles()
            self.render_profile_list()
            self.render_profile_editor()
            self.refresh_home()
            self.render_modules()

    # ---------- SETTINGS ----------
    def detect_java(self):
        res = []
        for root in ["C:\\Program Files\\Eclipse Adoptium","C:\\Program Files\\Java","C:\\Program Files (x86)\\Java"]:
            base = Path(root)
            if base.exists():
                for d in base.iterdir():
                    jp = d/"bin"/"java.exe"
                    if jp.exists():
                        res.append(str(jp))
        jh = os.environ.get("JAVA_HOME")
        if jh:
            jp = Path(jh)/"bin"/"java.exe"
            if jp.exists() and str(jp) not in res: res.append(str(jp))
        return res

    def build_settings(self):
        f = self.tabs["settings"]
        tk.Label(f, text="Settings", fg=ACCENT, bg=BG, font=("Segoe UI",24,"bold")).pack(anchor="w")
        card = tk.Frame(f, bg=PANEL2, padx=24, pady=20)
        card.pack(fill="x", pady=(14,0))
        r = tk.Frame(card, bg=PANEL2); r.pack(fill="x", pady=5)
        tk.Label(r, text="MC directory", fg=MUTED, bg=PANEL2, width=16, anchor="w", font=("Segoe UI",10)).pack(side="left")
        self.mcdir_var = tk.StringVar(value=S.get("minecraft_dir",str(MC)))
        tk.Entry(r, textvariable=self.mcdir_var, bg=PANEL, fg=TEXT, bd=0, insertbackground=TEXT, font=("Segoe UI",10)).pack(side="left", fill="x", expand=True, ipady=3)
        tk.Button(r, text="Choose", bg=PANEL, fg=MUTED, bd=0, padx=12, pady=4, command=self.choose_mc_dir).pack(side="left", padx=6)
        r = tk.Frame(card, bg=PANEL2); r.pack(fill="x", pady=5)
        tk.Label(r, text="Memory (MB)", fg=MUTED, bg=PANEL2, width=16, anchor="w", font=("Segoe UI",10)).pack(side="left")
        self.mem_var = tk.StringVar(value=str(S.get("memory_mb",2048)))
        tk.Entry(r, textvariable=self.mem_var, bg=PANEL, fg=TEXT, bd=0, insertbackground=TEXT, font=("Segoe UI",10), width=10).pack(side="left", ipady=3)
        r = tk.Frame(card, bg=PANEL2); r.pack(fill="x", pady=5)
        self.lowend_var = tk.BooleanVar(value=S.get("low_end_mode",False))
        tk.Checkbutton(r, text="Low-end mode (cap memory, reduce effects)", variable=self.lowend_var, bg=PANEL2, fg=TEXT, selectcolor=PANEL, font=("Segoe UI",10)).pack(anchor="w")
        r = tk.Frame(card, bg=PANEL2); r.pack(fill="x", pady=5)
        self.close_var = tk.BooleanVar(value=S.get("close_on_launch",True))
        tk.Checkbutton(r, text="Close launcher on launch", variable=self.close_var, bg=PANEL2, fg=TEXT, selectcolor=PANEL, font=("Segoe UI",10)).pack(anchor="w")
        tk.Button(card, text="Save settings", bg=ACCENT, fg="#000", bd=0, padx=16, pady=7, font=("Segoe UI",10,"bold"), command=self.save_settings_ui).pack(anchor="w", pady=10)
        tk.Button(card, text="Check for updates", bg=PANEL, fg=MUTED, bd=0, padx=16, pady=7, font=("Segoe UI",10), command=lambda: threading.Thread(target=self.check_for_updates, daemon=True).start()).pack(anchor="w", pady=(0,10))
        tk.Label(card, text="Detected Java:", fg=MUTED, bg=PANEL2, font=("Segoe UI",10,"bold")).pack(anchor="w", pady=(8,2))
        self.java_list_lbl = tk.Label(card, text="", fg=MUTED, bg=PANEL2, font=("Segoe UI",9), justify="left")
        self.java_list_lbl.pack(anchor="w")
        self.refresh_java_list()

    def choose_mc_dir(self):
        d = filedialog.askdirectory()
        if d:
            self.mcdir_var.set(d)
            S["minecraft_dir"]=d
            save_settings(S)

    def save_settings_ui(self):
        S["minecraft_dir"]=self.mcdir_var.get()
        try: S["memory_mb"]=int(self.mem_var.get())
        except: pass
        S["low_end_mode"]=self.lowend_var.get()
        S["close_on_launch"]=self.close_var.get()
        save_settings(S)
        self.set_status("Settings saved")

    def refresh_java_list(self):
        javas = self.detect_java()
        self.java_list_lbl.configure(text="\n".join(javas) if javas else "No Java found")

    def check_for_updates(self):
        try:
            import urllib.request, json
            data = urllib.request.urlopen(UPDATE_URL, timeout=10).read()
            info = json.loads(data)
            remote = info.get("version","")
            if remote and remote != APP_VERSION:
                msg = f"A new version ({remote}) is available.\n\nUpdate now?"
                self.after(0, lambda: self._prompt_update(msg, info.get("download_url", DOWNLOAD_URL)))
            else:
                self.after(0, lambda: self.set_status(f"Up to date ({APP_VERSION})"))
        except Exception as e:
            self.after(0, lambda: self.set_status(f"Update check failed: {e}"))

    def _prompt_update(self, msg, url):
        if messagebox.askyesno(APP, msg):
            threading.Thread(target=self.do_update, args=(url,), daemon=True).start()

    def do_update(self, url):
        try:
            import urllib.request, zipfile, io, os, sys, subprocess
            self.after(0, lambda: self.set_status("Downloading update..."))
            data = urllib.request.urlopen(url, timeout=60).read()
            z = zipfile.ZipFile(io.BytesIO(data))
            base = Path(__file__).parent
            z.extractall(base)
            self.after(0, lambda: self.set_status("Update installed. Restarting..."))
            # restart
            python = sys.executable
            script = base / "pickle_launcher.py"
            subprocess.Popen([python, str(script)])
            self.after(0, self.destroy)
        except Exception as e:
            self.after(0, lambda: messagebox.showerror(APP, f"Update failed: {e}"))

    # ---------- launch ----------
    def launch(self):
        p = self.profiles[self.selected_profile] if self.profiles else {}
        gv = p.get("game_version") or self.selected_version or "1.20.4"
        mc_dir = Path(S["minecraft_dir"])
        java = S.get("java_path","")
        if not java:
            js = self.detect_java()
            java = js[0] if js else ""
        if not java:
            messagebox.showerror(APP,"No Java found. Install Java first."); return
        version_id = gv
        loader = p.get("loader","Vanilla")
        if loader and loader != "Vanilla":
            cand = f"{gv}-{loader.lower()}"
            if (mc_dir/"versions"/cand).exists():
                version_id = cand
            else:
                for d in (mc_dir/"versions").iterdir() if (mc_dir/"versions").exists() else []:
                    if d.is_dir() and d.name.startswith(gv) and loader.lower() in d.name.lower():
                        version_id = d.name; break
        vjson = mc_dir/"versions"/version_id/f"{version_id}.json"
        if not vjson.exists():
            messagebox.showerror(APP, f"Version not installed: {version_id}. Install first."); return
        v = json.loads(vjson.read_text())
        main_class = v.get("mainClass","net.minecraft.client.main.Main")
        cp = []
        for lib in v.get("libraries",[]):
            dl = lib.get("downloads",{})
            art = dl.get("artifact")
            if art and art.get("path"):
                pp = mc_dir/"libraries"/art["path"]
                if pp.exists(): cp.append(str(pp))
            cls = dl.get("classifiers",{})
            art2 = cls.get("natives-windows")
            if art2 and art2.get("path"):
                pp = mc_dir/"libraries"/art2["path"]
                if pp.exists(): cp.append(str(pp))
        jar = mc_dir/"versions"/version_id/f"{version_id}.jar"
        if jar.exists(): cp.append(str(jar))
        natives = mc_dir/"natives"/version_id
        natives.mkdir(parents=True, exist_ok=True)
        mem = p.get("memory_mb") or S.get("memory_mb",2048)
        if S.get("low_end_mode"): mem = min(mem,1024)
        args = [f"-Xmx{mem}M", f"-Xms{max(512,mem//2)}M", f"-Djava.library.path={natives}", "-cp", ";".join(cp), main_class,
                "--username","Player","--version",version_id,"--gameDir",str(mc_dir),"--assetsDir",str(mc_dir/"assets")]
        ai = v.get("assetIndex",{}).get("id")
        if ai: args += ["--assetIndex", ai]
        self.set_status(f"Launching {p.get('name','Default')}...")
        def worker():
            subprocess.run([java]+args, check=False)
        threading.Thread(target=worker, daemon=True).start()

    def open_mc_folder(self):
        self.open_path(MC)
    def open_path(self, p):
        try:
            os.startfile(str(p))
        except Exception as e:
            self.set_status(str(e))

if __name__ == "__main__":
    app = App()
    app.mainloop()

