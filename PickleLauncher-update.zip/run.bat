@echo off
cd /d "%~dp0"
python pickle_launcher.py
pause
